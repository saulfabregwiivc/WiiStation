#ifndef __LIBFATVERSION_H__
#define __LIBFATVERSION_H__

#define _LIBFAT_MAJOR_	1
#define _LIBFAT_MINOR_	1
#define _LIBFAT_PATCH_	5

#define _LIBFAT_STRING "libFAT Release 1.1.5"

#endif // __LIBFATVERSION_H__
